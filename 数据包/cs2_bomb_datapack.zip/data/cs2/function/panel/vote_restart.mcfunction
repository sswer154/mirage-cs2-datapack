scoreboard players reset @s cs2_vote_restart
scoreboard players enable @s cs2_vote_restart
execute if score #paused cs2_counts matches 1 run tellraw @s {"text":"暂停中不能投票。","color":"red"}
execute if score #paused cs2_counts matches 1 run return 0
execute unless score #state cs2_state matches 3..4 run tellraw @s {"text":"只有回合进行中才能投票重开。","color":"red"}
execute unless score #state cs2_state matches 3..4 run return 0
execute unless score #solo cs2_counts matches 0 run tellraw @s {"text":"练习模式不能使用重开投票。","color":"red"}
execute unless score #solo cs2_counts matches 0 run return 0
execute unless score @s cs2_inmatch matches 1 run tellraw @s {"text":"你不是本场参赛者。","color":"red"}
execute unless score @s cs2_inmatch matches 1 run return 0
execute if score @s cs2_voted_restart matches 1 run tellraw @s {"text":"你已经同意重开本小局了。","color":"yellow"}
execute if score @s cs2_voted_restart matches 1 run return 0
scoreboard players set @s cs2_voted_restart 1
function cs2:panel/recount_votes
tellraw @a[scores={cs2_inmatch=1}] [{"text":"重开投票：","color":"green"},{"text":"已同意 ","color":"gray"},{"score":{"name":"#vote_restart_yes","objective":"cs2_counts"}},{"text":"/","color":"gray"},{"score":{"name":"#vote_total","objective":"cs2_counts"}},{"text":" 人","color":"gray"}]
