# 幻梦奇谭 · 子弹平衡包

模板骨架。里面有一个可以直接进游戏的枪口配件样本，照它复制改名就能加自己的。

## 目录

```
幻梦奇谭子弹平衡包1.0/
├─ gunpack.meta.json              命名空间 + 支持的 MC 版本
├─ README.md
├─ assets/huanmeng/
│  ├─ gunpack_info.json           包名、描述、作者（枪械工作台里显示的那张卡）
│  ├─ lang/{zh_cn,en_us}.json     所有显示名都走这里
│  ├─ display/                    配件效果：用哪个模型、哪张贴图、什么音效
│  ├─ geo_models/attachment/      基岩版模型（16×16 贴图空间）
│  └─ textures/attachment/
│     ├─ uv/                      模型贴图
│     └─ slot/                    背包 2D 图标
└─ data/huanmeng/
   ├─ index/attachments/          物品定义（文件名就是 id）
   └─ data/attachments/           数值定义
```

## 加一个新配件的四步

1. 复制 `data/huanmeng/index/attachments/template_muzzle.json`，文件名改成新 id，例如 `muzzle_brake_01.json`。
   里面三行指向改掉：`display` / `data` / `tooltip`。
2. 复制 `data/huanmeng/data/attachments/template_muzzle_data.json` 改成 `muzzle_brake_01_data.json`，改数值。
3. 复制 `assets/huanmeng/display/template_muzzle_display.json` 改成 `muzzle_brake_01_display.json`，
   指向新的模型和贴图路径。
4. 复制模型和两张贴图，改文件名；语言文件里补两条（名字 + 说明）。

## 数值怎么算

最终值 =（基础值 + Σ加数）×（1 + Σ百分比）× Π乘数

三个乘区不用全写，没写的跳过。例：

```json
"ads": { "addend": 0.02, "percent": 0.1, "multiplier": 1.05 }
```

不能套乘区、要单独写的字段：`weight`（kg，直接加）、`silence`、`extended_mag_level`（1/2/3）、
`ignite`、`explosion`、`recoil`（pitch/yaw 各带乘区）、`recoil_push`、`melee`。

注意：游戏里显示的数值会隐藏小数，但计算时不会省略。

## 现在这个样本

`template_muzzle` 是个枪口类配件：

- 重量 0.1 kg
- 开镜时间 +0.01 秒
- 腰射精度 -15%（负数是变准）
- 开镜精度 -5%
- 后坐力 竖直 -4%、水平 -3%

模型只是一个方块，贴图是网格占位图。换成真模型时记得：朝向北、位于 Z 轴线上、
网格中心会渲染到枪械模型的定位组位置。

## 背包图标规范（2026-11-09 定）

生成脚本：`D:\AI\Sandrone\scripts\make_icon.py --src 原图 --type 弹种 --caliber 口径 --out 输出.png`

1. 画布 64×64，原图按原尺寸贴进去，不缩放、不裁剪、不重采样。原图小就留透明边。
2. 左上角写弹种代号（PS / BP / BT 之类，随弹药变），Arial Bold 15 号，白色，向右下各偏 1 像素描黑边。
3. 底部一条高 13 像素、透明度 150 的黑色横带，压在上面写字用。
4. 口径写在横带上、水平居中，Arial Bold 从 12 号往下试，直到宽度不超过 62 像素为止。
5. 文字一律白色 + 1 像素黑描边，别用渐变、别用阴影，缩小后会糊。
6. 图标走 `assets/<ns>/textures/attachment/slot/<id>.png`；模型的 UV 贴图由 `make_mag_plate.py` 生成 128×128（正面 64×64 原图 1:1，右侧一列作厚度边），不要跟图标混用同一个文件。
7. 四角是直角（`--square`），外面一圈白边（`--border` 可换色），底板灰 `#6C6E74`。

### 让配件挂在枪上不显示

display 文件里**不写 `model` 和 `texture`**，配件就不会渲染模型，功能照旧。2026-11-13 用这个办法把
`l191_57_muzzle` 和 `ss197sr_57_laser` 改成隐身，原来的可见版本留在 `.bak-visible`。

### 淡黄边框是「穿甲弹」的标记，不是规律

- `--border #F0E68C` 表示这是穿甲弹。她默认做的就是穿甲弹，所以黄边居多。
- **不要**把「同口径里穿透最高的那张标黄」当成规则去套；现在的黄边是逐个指定出来的，跟数值高低没有推导关系。
- 2026-11-10 的教训：我按「每组穿透最高」重刷了一遍，被她纠正。

为什么不能用 32×32：TACZ 自带的图标是按 32 像素逐点画的，没有缩放；从 64 缩到 32 会丢一半细节，
再加半透明边缘互相渗色，字必糊。尺寸相同不等于能承载的细节相同。

## 现有配件一览（2026-11-09）

排序值越小越靠前。同口径按穿透从高到低，口径按数字从大到小（9 → 7.62 → 5.8 → 5.56 → 5.45 → 4.6 → 5.7）。

| sort | 名称 | 槽位 | 数值 | id |
|---|---|---|---|---|
| 90 | .45 ACP Hydra-Shok | 弹匣 | 穿甲 -0.07；伤害 +0.5；三级弹容 | hydrashok_45_mag |
| 100 | 9x19mm 7N31 | 弹匣 | 穿甲 +0.15；伤害 -1；三级弹容 | n7n31_9x19_mag |
| 109 | 7.62x39mm PP | 弹匣 | 穿甲 +0.15；二级弹容 | pp_762_mag |
| 110 | 7.62x39mm PS | 弹匣 | 穿甲 +0.10；爆头 +0.10 | ps_762x39_mag |
| 111 | 7.62x39mm HP | 弹匣 | 穿甲 -0.15；伤害 +1 | hp_762_mag |
| 120 | 5.8x42mm DBP191 | 弹匣 | 爆头 +0.15 | dbp191_58_mag |
| 130 | 5.56x45mm M856A1 | 弹匣 | 穿甲 +0.10；爆头 +0.15 | m856a1_556_mag |
| 131 | 5.56x45mm HP | 弹匣 | 穿甲 -0.18；伤害 +3；爆头 -0.25 | hp_556_mag |
| 140 | 5.45x39mm BT | 弹匣 | 穿甲 +0.12 | bt_545_mag |
| 141 | 5.45x39mm SP | 弹匣 | 穿甲 -0.10；伤害 +1 | sp_545_mag |
| 150 | 4.6x30mm FMJ SX | 弹匣 | 穿甲 -0.25；爆头 +0.25；三级弹容 | fmjsx_46_mag |
| 160 | 5.7x28mm L191 | 激光 | 穿甲 -0.39 | l191_57_muzzle |
| 161 | 5.7x28mm SS197SR | 激光 | 穿甲 -0.45 | ss197sr_57_laser |
| 1000 | 模板 · 枪口 | 枪口 | 无 | template_muzzle |

## 谁能装：按弹药限定

配件本身不记口径，枪的白名单只认槽位和标签。所以「只给同弹药的枪」是靠**给枪补白名单**做的：

1. 读 `data/tacz/data/guns/<枪>_data.json` 里的 `"ammo"` 字段，得到这把枪用什么弹。
2. 把 `data/tacz/tacz_tags/attachments/allow_attachments/<枪>.json` 原样抄一份到本包，末尾追加我们的配件 id。
3. 我们的包会覆盖默认包的同名文件，其余条目一条不动。

已覆盖的枪：7.62x39 四把（ak47、rpk、sks_tactical、type_81）、5.45x39 三把（ak12、ak74m、qr_24）、
5.56x45 十一把、5.8x42 两把（qbz_191、qbz_95）、9mm 七把（手枪与冲锋枪）、4.6x30 一把（hk_mp7a1）、
5.7x28 一把（p90）。

全局标签（`extended_mag` / `light_extended_mag`）**保持原样**，只有默认那三个弹匣，
别往里加自己的 id，否则所有开这个槽的枪都能装。

想撤销某个限定：删掉本包里对应的 `<枪>.json` 即可恢复默认。

## 加新弹药时的固定流程

1. 在 eftarkov.com 的 `/ammo` 页面找弹药的 `item` id，拼出
   `https://www.eftarkov.com/uploads/base/<id>-base-image.webp` 下载原图。
2. 用 `make_icon.py` 出背包图标（64×64），再用 `make_mag_plate.py` 出 128×128 的模型贴图。
3. 抄一套 index / data / display / geo / lang 五份，改 id 和数值。
4. 用上面的「按弹药限定」流程补枪的白名单。
5. 按排序规则给 `sort` 一个值：口径降序分段（100、110、120…），段内按穿透降序（+10、+1）。
